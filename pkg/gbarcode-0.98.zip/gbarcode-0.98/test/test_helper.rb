require 'test/unit'
require 'gbarcode'