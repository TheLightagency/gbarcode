#!/usr/bin/env ruby
#
#  Created by Angel Pizarro on 2007-03-15.
#  Copyright (c) 2007. All rights reserved.
require 'mkmf'
create_makefile('gbarcode')